plugins {
id("com.android.application")
id("org.jetbrains.kotlin.android")
id("org.jetbrains.kotlin.plugin.compose")
id("com.google.gms.google-services")
}

android {
namespace = "com.vibe.chat"
compileSdk = 35

defaultConfig {
    applicationId = "com.vibe.chat"
    minSdk = 26
    targetSdk = 35
    versionCode = 3
    versionName = "1.2.0"
}

buildFeatures {
    compose = true
}

compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

kotlin {
    compilerOptions {
        jvmTarget.set(
            org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
        )
    }
}

}

dependencies {
implementation("androidx.core:core-ktx:1.15.0")
implementation("androidx.activity:activity-compose:1.10.0")

implementation(
    platform("androidx.compose:compose-bom:2024.12.01")
)

implementation("androidx.compose.ui:ui")
implementation("androidx.compose.ui:ui-tooling-preview")
implementation("androidx.compose.material3:material3")

// Расширенные значки интерфейса
implementation("androidx.compose.material:material-icons-extended:1.7.6")

implementation(platform("com.google.firebase:firebase-bom:34.19.0"))
implementation("com.google.firebase:firebase-auth")
implementation("com.google.firebase:firebase-firestore")
implementation("com.google.firebase:firebase-ai")
implementation("com.google.firebase:firebase-appcheck-debug")
implementation("com.google.firebase:firebase-storage")

// Отображение аватарок по ссылкам
implementation("io.coil-kt:coil-compose:2.7.0")

debugImplementation("androidx.compose.ui:ui-tooling")

}
